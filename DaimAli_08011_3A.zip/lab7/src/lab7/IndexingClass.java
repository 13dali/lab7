package lab7;


import java.util.ArrayList;

public class IndexingClass implements Runnable {

	
	private ArrayList<String> paths;
	private ArrayList<String> f_size;
	private ArrayList<String> contents_file;
	private ArrayList<String> recent_modification;
	private ArrayList<String> owner;
	
	public IndexingClass(){
		
		this.recent_modification = new ArrayList<String>();
		this.owner = new ArrayList<String>();
		this.contents_file = new ArrayList<String>();
		this.paths = new ArrayList<String>();
		this.f_size = new ArrayList<String>();
	}
	
	public void run(){
		
		while(true){
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			if(MyCrawler.contents_file.size()>0 ){
				
				int i=0;
				while (i<MyCrawler.contents_file.size())
				{
					this.contents_file.add(MyCrawler.contents_file.get(i));
					this.paths.add(MyCrawler.paths.get(i));
					this.f_size.add(MyCrawler.f_size.get(i));
					this.recent_modification.add(MyCrawler.recent_modification.get(i));
					this.owner.add(MyCrawler.owner.get(i));
					
					i++;
				}
				MyCrawler.f_size.clear();
				MyCrawler.recent_modification.clear();
				MyCrawler.owner.clear();
				MyCrawler.contents_file.clear();
				MyCrawler.paths.clear();
				
				int j=0;
				while(j< this.contents_file.size())
				{
					MainClass.contents_file.add(this.contents_file.get(j));
					MainClass.paths.add(this.paths.get(j));
					MainClass.f_size.add(this.f_size.get(j));
					MainClass.recent_modification.add(this.recent_modification.get(j));
					MainClass.owner.add(this.owner.get(j));
					
					j++;
				}
				
				this.f_size.clear();
				this.recent_modification.clear();
				this.owner.clear();
				this.contents_file.clear();
				this.paths.clear();
				
				
			}
		}
		
	}

}

