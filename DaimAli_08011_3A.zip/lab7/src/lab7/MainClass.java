package lab7;


import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class MainClass {
	
	String file_root;
	File folder;
	File[] files_list;
	
	
	public static ArrayList<String> f_size;
	public static ArrayList<String> recent_modification;
	public static ArrayList<String> owner;
	public static ArrayList<String> contents_file;
	public static ArrayList<String> paths;
	
	public MainClass(){
		
		f_size = new ArrayList<String>();
		recent_modification = new ArrayList<String>();
		owner = new ArrayList<String>();
		contents_file = new ArrayList<String>();
		paths = new ArrayList<String>();
		
		this.file_root = "E://";
		folder = new File(this.file_root);
		files_list = folder.listFiles();
		
		
	}
	
	public ArrayList<String> getFile_Content(){
		return MainClass.contents_file;
	}
	public ArrayList<String> getFile_Path(){
		return MainClass.paths;
	}
	
	public ArrayList<String> getFile_size(){
		return MainClass.f_size;
	}
	public ArrayList<String> getlasModified(){
		return MainClass.recent_modification;
	}
	
	public String getroot(){
		return this.file_root;
	}
	
	
	
	@SuppressWarnings("resource")
	public static void main(String[] args) throws InterruptedException {
		
		MainClass cm = new MainClass();
		
		Thread ind = new Thread(new IndexingClass());
		ind.setDaemon(true);
		ind.start();
		
		Thread CrawlerThread = new Thread(new MyCrawler(cm.file_root));
		CrawlerThread.start();
		CrawlerThread.join();
		
		System.out.println("enter the string to be searched:");
		Scanner s = new Scanner(System.in);
		String search = s.next();
		
		Thread SearchThread = new Thread(new SearchClass( search));
		SearchThread.start();
		
		
		
	}

}
