package lab7;


import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.BasicFileAttributes;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class MyCrawler implements Runnable {
	
	public String file_root;
	public static ArrayList<String> f_size;
	public static ArrayList<String> recent_modification;
	public static ArrayList<String> owner;
	public static ArrayList<String> contents_file;
	public static ArrayList<String> paths;
	
	public MyCrawler(String r){
		file_root = r;
		MyCrawler.f_size = new ArrayList<String>();
		MyCrawler.recent_modification = new ArrayList<String>();
		MyCrawler.owner = new ArrayList<String>();
		MyCrawler.contents_file = new ArrayList<String>();
		MyCrawler.paths = new ArrayList<String>();
	}

	public String parser(File f){
		List<String> connections = null;
		String con = "";
		try {
			connections = Files.readAllLines(Paths.get(f.getAbsolutePath()),StandardCharsets.UTF_8);
		} catch (IOException e) {}
		
		int i=0;
		while(i<connections.size())
		{
			con += (String) connections.get(i);
			i++;
		}
		return con;
	}
	
	public void find( String path ) {

		File file_root = new File( path );
		File[] list = file_root.listFiles();

		if (list == null) return;

		for ( File f : list ) {
			if ( !f.isDirectory() ) {
				
               SimpleDateFormat data_format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
				
				if(f.getName().contains(".txt")){
					MyCrawler.contents_file.add(parser(f));
					MyCrawler.f_size.add(""+f.length()+" Bytes");
					MyCrawler.recent_modification.add(""+data_format.format(f.lastModified()));
					
					if(f.canRead())
						
						if(f.canRead())
							MyCrawler.owner.add("Read : False & Write : True");
						else
							MyCrawler.owner.add("Read : False & Write : False");
					else
						if(f.canRead())
							MyCrawler.owner.add("Read : True & Write : True");
						else
							MyCrawler.owner.add("Read : True & Write : False");
						
					
					MyCrawler.paths.add(f.getAbsolutePath());
				}
				
			}
			else {
				try{
					find( f.getAbsolutePath() );
				}catch(Exception e){}
			}
		}
	}
	
	

	public void run() {
		find(this.file_root);
		
	}	
	
}
