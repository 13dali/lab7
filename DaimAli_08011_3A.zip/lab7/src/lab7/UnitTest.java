package lab7;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import java.io.File;

public class UnitTest {

	@Test
	
public void second_test(){
		
		MainClass cm = new MainClass();
		File f = new File(cm.file_root);
		
		if(!f.exists()){
			fail("File not exist");
		}
	}
	
	
	public void fisrt_test() {

		MainClass cm = new MainClass();
		assertEquals("E://LabN004", cm.file_root);
		
	}
	
}
