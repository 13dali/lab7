package lab7;

public class SearchClass implements Runnable {
	
	public String search;
	
	public SearchClass(String s){
		this.search = s;
	}

	public void search(String s){
		
		int i=0;
		while(i<MainClass.paths.size())
		{
			if(MainClass.paths.get(i).contains(s) || MainClass.contents_file.get(i).contains(s))
				System.out.println("Found At : "+MainClass.paths.get(i));
			System.out.println("Las Modified at : "+MainClass.recent_modification.get(i));
			System.out.println("Ownership Status : "+MainClass.owner.get(i));
			System.out.println("Size of File is : "+MainClass.f_size.get(i));
				
				System.out.println();
				i++;
		}
	}
	
	public void run() {
		search(this.search);
	}	
}
